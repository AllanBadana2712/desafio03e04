import React from "react";
import {View, Text} from 'react-native';

export default function Informacoes (){
    return(
        <View>
            <Text>Informações</Text>
        </View>
    )
}